let elUserForm=document.querySelector('.user-form');
let elUserInput=document.querySelector('.user-input');
let elUserList=document.querySelector('.user-list');

function render(arr, node) {
   node.innerHTML=null;
   let countAll=0;
   let countCompleted=0;
   let unCountCompleted=0;
   
   arr.forEach((todo) => { 
      let newUserItem=document.createElement('li');

      let newUserCheckbox=document.createElement('input');
      let newUserButton=document.createElement('button');

      newUserCheckbox.type='checkbox';
      newUserCheckbox.setAttribute('class', 'user-delete-checkbox');
      newUserCheckbox.dataset.deletecheckboxId=todo.id;

      if(todo.isCompleted) {
         newUserCheckbox.checked=true;
         countCompleted++;
      }

      newUserButton.textContent='delete';
      newUserButton.setAttribute('class','user-delete-button');
      newUserButton.dataset.deleteButtonId=todo.id;
      
      newUserItem.textContent=todo.title;

      newUserItem.appendChild(newUserCheckbox);
      newUserItem.appendChild(newUserButton);
      node.appendChild(newUserItem);

      countAll++;
   }); 
   
   allCount(countAll);
   completedCount(countCompleted);
   unCountCompleted=countAll-countCompleted;
   unCompletedCount(unCountCompleted);
}

elUserList.addEventListener('click', (evt)=>{
   evt.preventDefault();
   if(evt.target.matches('.user-delete-button')){
      let deleteButton=Number(evt.target.dataset.deleteButtonId);
      
      let foundDeleteButtonId=todos.findIndex((todo)=> todo.id===deleteButton);
      
      todos.splice(foundDeleteButtonId, 1);

      render(todos, elUserList);
   } else if(evt.target.matches('.user-delete-checkbox')) {
      let deleteCheckbox=Number(evt.target.dataset.deletecheckboxId);
      
      let foundCheckbox=todos.find((todo)=>todo.id===deleteCheckbox);

      foundCheckbox.isCompleted=!foundCheckbox.isCompleted;
      
      render(todos, elUserList);
   };
});

let todos=[];
elUserForm.addEventListener('submit', (evt)=>{
   evt.preventDefault();

   let inputValue=elUserInput.value.trim();
   
   let newTodo={
      id: todos[todos.length-1]?.id+1 || 0,
      title: inputValue, 
      isCompleted: false,
   }
   
   todos.push(newTodo);
   render(todos, elUserList); 
   elUserInput.value=null;
   
});

// ==================================//

let elAll=document.querySelector('.all');
let elCompleted=document.querySelector('.completed');
let elUncompleted=document.querySelector('.uncompleted');

function allCount(number) {
   let elAllCount=document.querySelector('.all-count');
   elAllCount.textContent=number;
}

function completedCount(number) {
   let elCompletedCount=document.querySelector('.completed-count');
   elCompletedCount.textContent=number; 
}

function unCompletedCount(number) {
   let elUncompletedCount=document.querySelector('.uncompleted-count');
   elUncompletedCount.textContent=number;
}

elAll.addEventListener('click', function(evt) {
   evt.preventDefault();

   render(todos, elUserList);
});

elCompleted.addEventListener('click', function(evt) {
   evt.preventDefault();

   renderCompleted(todos, elUserList);
});

elUncompleted.addEventListener('click', function(evt) {
   evt.preventDefault();

   renderUnCompleted(todos, elUserList);
});

let todoCompleted=[];
function renderCompleted(arr, node) {
   node.innerHTML=null;

   arr.forEach((todo)=>{
      if(todo.isCompleted) {
         todoCompleted.push=todo;
         let newUserItem=document.createElement('li');

         let newUserCheckbox=document.createElement('input');
         let newUserButton=document.createElement('button');

         newUserCheckbox.type='checkbox';
         newUserCheckbox.setAttribute('class', 'user-delete-checkbox');
         newUserCheckbox.dataset.deletecheckboxId=todo.id;

         if(todo.isCompleted) {
            newUserCheckbox.checked=true;
         }

         newUserButton.textContent='delete';
         newUserButton.setAttribute('class','user-delete-button');
         newUserButton.dataset.deleteButtonId=todo.id;
         
         newUserItem.textContent=todo.title;

         newUserItem.appendChild(newUserCheckbox);
         newUserItem.appendChild(newUserButton);
         node.appendChild(newUserItem);

      }
   });
}

let todoUnCompleted=[];
function renderUnCompleted(arr, node) {
   node.innerHTML=null;

   arr.forEach((todo)=>{
      if(!todo.isCompleted) {
         todoUnCompleted.push=todo;
         let newUserItem=document.createElement('li');

         let newUserCheckbox=document.createElement('input');
         let newUserButton=document.createElement('button');

         newUserCheckbox.type='checkbox';
         newUserCheckbox.setAttribute('class', 'user-delete-checkbox');
         newUserCheckbox.dataset.deletecheckboxId=todo.id;

         if(todo.isCompleted) {
            newUserCheckbox.checked=true;
         }

         newUserButton.textContent='delete';
         newUserButton.setAttribute('class','user-delete-button');
         newUserButton.dataset.deleteButtonId=todo.id;
         
         newUserItem.textContent=todo.title;

         newUserItem.appendChild(newUserCheckbox);
         newUserItem.appendChild(newUserButton);
         node.appendChild(newUserItem);

      }
   });
}

